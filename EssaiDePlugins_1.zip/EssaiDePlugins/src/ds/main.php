<?php

namespace ds;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase implements listener{
   
       public function onEnable(): void 
       {
       	    $this->getLogger()->notice("Le plugin a été activé");
       }
        
       public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
       {
            if(!$sender instanceof Player){
                return true;
            }

            switch ($command->getName()){
                case "discord":
                    $sender->sendMessage("Rejoignez des dizaines de personnes avec qui parler sur le Discord -> https://discord.gg/cpZQ2fazuD");
                    break;
                case "feed":
                    $sender->getHungerManager()->setFood(20);
                    $sender->getHungerManager()->setSaturation(20);
                    $sender->sendMessage("Vous avez bien été nourris");
                    break;
                case "nightvision":
                    if($sender->getEffects()->has(VanillaEffects::NIGHT_VISION())){
                        $sender->getEffects()->remove(VanillaEffects::NIGHT_VISION());
                        $sender->sendMessage("Vous n'êtes plus équipé de l'effet de Vision Nocturne");
                    }else{
                        $sender->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(),25000,1,false));
                        $sender->sendMessage("Vous avez obtenu l'effet de vision nocturne");
                    }
                    break;
            }

            return true;
       }
}